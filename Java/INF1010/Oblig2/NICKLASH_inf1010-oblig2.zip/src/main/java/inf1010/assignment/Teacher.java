package inf1010.assignment;

public interface Teacher {	


public Subject getSubject();
public Student [] getStudents();

}
