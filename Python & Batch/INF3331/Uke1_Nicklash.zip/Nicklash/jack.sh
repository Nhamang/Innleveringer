#!/bin/bash
#Navn: Nicklas M. Hamang. Brukernavn: Nicklash
#ingen input
trap 'echo All play and no work makes Jack a mere toy; exit' SIGINT 
while true :
do echo "All work an no play makes Jack a dull boy."
done