#Navn: Nicklas M. Hamang Brukernavn: nicklash
import random
random=random.uniform(-1, 1)
print("%.4f"%random)

#Runtime ex.
#C:\Users~~\Uke2>python printrandom.py
#
#-0.4456
#-0.3008
#0.6920
