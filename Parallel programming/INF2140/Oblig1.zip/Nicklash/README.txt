Everything runs as described in the assignment text. 
I have no questions for the teacher. 
I had no assumptions. 
I am not aware of anything missing.
