package no.uio.ifi.pma.inf2140;


public interface IRadioController {

	void eventScan();

	void eventLock();

	void eventOn();

	void eventOff();

	void eventReset();


}
