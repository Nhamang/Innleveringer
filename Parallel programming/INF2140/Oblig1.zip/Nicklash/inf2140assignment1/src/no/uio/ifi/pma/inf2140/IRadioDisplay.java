package no.uio.ifi.pma.inf2140;


import java.awt.Color;

public interface IRadioDisplay {

	void setColor(Color red);

	void setText(String string);

	void setAngle(int i);

}
