package no.uio.ifi.pma.inf2140;


public interface IRotator {

	void stopScanning();

	void startScanning();

}
